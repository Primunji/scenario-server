package dev.euns.fishingstopserver

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class FishingstopServerApplicationTests {

    @Test
    fun contextLoads() {
    }

}
