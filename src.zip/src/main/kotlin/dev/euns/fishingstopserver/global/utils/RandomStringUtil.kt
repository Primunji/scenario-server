package dev.euns.fishingstopserver.global.utils

import org.springframework.stereotype.Component

@Component
class RandomStringUtil {
    fun getRandomString(length: Int) : String {
        val charset = "ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz0123456789"
        return (1..length)
            .map { charset.random() }
            .joinToString("")
    }
}