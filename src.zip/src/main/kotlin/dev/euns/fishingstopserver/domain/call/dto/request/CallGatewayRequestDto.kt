package dev.euns.fishingstopserver.domain.call.dto.request

data class CallGatewayRequestDto(
    val message: String
)