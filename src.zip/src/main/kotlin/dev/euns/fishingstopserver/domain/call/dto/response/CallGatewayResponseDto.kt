package dev.euns.fishingstopserver.domain.call.dto.response

data class CallGatewayResponseDto(val status: String, val message: String)
